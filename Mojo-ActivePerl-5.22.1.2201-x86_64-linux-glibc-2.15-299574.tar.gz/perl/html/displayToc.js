function writelinks(anchorName, depth) {
}
