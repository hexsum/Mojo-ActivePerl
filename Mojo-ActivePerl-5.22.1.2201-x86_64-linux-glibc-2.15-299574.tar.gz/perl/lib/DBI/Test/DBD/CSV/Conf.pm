#!/usr/bin/perl

package DBI::Test::DBD::CSV::Conf;

use strict;
use warnings;
use parent qw( DBI::Test::Conf );

1;
